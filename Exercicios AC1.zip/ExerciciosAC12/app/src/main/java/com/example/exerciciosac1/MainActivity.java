package com.example.exerciciosac1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnEx1).setOnClickListener(v -> abrirTela(Exercicio1Activity.class));
        findViewById(R.id.btnEx2).setOnClickListener(v -> abrirTela(Exercicio2Activity.class));
        findViewById(R.id.btnEx3).setOnClickListener(v -> abrirTela(Exercicio3Activity.class));
        findViewById(R.id.btnEx4).setOnClickListener(v -> abrirTela(Exercicio4Activity.class));
        findViewById(R.id.btnEx5).setOnClickListener(v -> abrirTela(Exercicio5Activity.class));
    }

    private void abrirTela(Class<?> activity) {
        Intent intent = new Intent(this, activity);
        startActivity(intent);
    }
}
package com.example.exerciciosac1;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Exercicio5Activity extends AppCompatActivity {
    CheckBox cbNotificacoes, cbModoEscuro, cbLembrarLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio5);

        cbNotificacoes = findViewById(R.id.cbNotificacoes);
        cbModoEscuro = findViewById(R.id.cbModoEscuro);
        cbLembrarLogin = findViewById(R.id.cbLembrarLogin);
    }

    public void salvarPreferencias(View view) {
        StringBuilder mensagem = new StringBuilder();

        if (cbNotificacoes.isChecked()) mensagem.append("Receber Notificações\n");
        if (cbModoEscuro.isChecked()) mensagem.append("Modo Escuro\n");
        if (cbLembrarLogin.isChecked()) mensagem.append("Lembrar Login\n");

        if (mensagem.length() == 0) {
            mensagem.append("Nenhuma preferência foi escolhida");
        }

        Toast.makeText(this, mensagem.toString(), Toast.LENGTH_LONG).show();
    }
}
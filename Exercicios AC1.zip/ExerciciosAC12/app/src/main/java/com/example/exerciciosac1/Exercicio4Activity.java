package com.example.exerciciosac1;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class Exercicio4Activity extends AppCompatActivity {
    EditText etNome;
    LinearLayout layoutCheckboxes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio4);

        etNome = findViewById(R.id.etNome);
        layoutCheckboxes = findViewById(R.id.layoutCheckboxes);
    }

    public void gerarCheckboxes(View view) {
        layoutCheckboxes.removeAllViews(); // Limpa os checkboxes anteriores
        String nome = etNome.getText().toString();

        for (char letra : nome.toCharArray()) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(String.valueOf(letra));
            layoutCheckboxes.addView(checkBox);
        }
    }
}
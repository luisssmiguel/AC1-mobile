package com.example.exerciciosac1;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Exercicio3Activity extends AppCompatActivity {
    EditText etNome, etIdade, etUf, etCidade, etTelefone, etEmail;
    RadioButton rbP, rbM, rbG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio3);

        etNome = findViewById(R.id.etNome);
        etIdade = findViewById(R.id.etIdade);
        etUf = findViewById(R.id.etUf);
        etCidade = findViewById(R.id.etCidade);
        etTelefone = findViewById(R.id.etTelefone);
        etEmail = findViewById(R.id.etEmail);
        rbP = findViewById(R.id.rbP);
        rbM = findViewById(R.id.rbM);
        rbG = findViewById(R.id.rbG);
    }

    public void cadastrar(View view) {
        String nome = etNome.getText().toString();
        String idade = etIdade.getText().toString();
        String uf = etUf.getText().toString();
        String cidade = etCidade.getText().toString();
        String telefone = etTelefone.getText().toString();
        String email = etEmail.getText().toString();

        String tamanho = rbP.isChecked() ? "P" : rbM.isChecked() ? "M" : rbG.isChecked() ? "G" : "Não informado";

        Toast.makeText(this, "Cadastro:\n" + nome + "\nIdade: " + idade + "\nUF: " + uf + "\nCidade: " + cidade + "\nTelefone: " + telefone + "\nEmail: " + email + "\nTamanho: " + tamanho, Toast.LENGTH_LONG).show();
    }
}
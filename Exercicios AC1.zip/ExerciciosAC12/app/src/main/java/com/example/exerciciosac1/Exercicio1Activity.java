package com.example.exerciciosac1;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Exercicio1Activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio1);
    }

    public void verificarIdade(View view) {
        EditText etNome = findViewById(R.id.etNome);
        EditText etIdade = findViewById(R.id.etIdade);
        TextView tvResultado = findViewById(R.id.tvResultado);

        String nome = etNome.getText().toString();
        int idade = Integer.parseInt(etIdade.getText().toString());

        tvResultado.setText(nome + " é " + (idade >= 18 ? "Maior de idade" : "Menor de idade"));
    }
}
package com.example.exerciciosac1;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Exercicio2Activity extends AppCompatActivity {
    EditText etNum1, etNum2;
    TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio2);

        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);
        tvResultado = findViewById(R.id.tvResultado);
    }

    public void calcular(View view) {
        // Validação de entrada
        if (etNum1.getText().toString().isEmpty() || etNum2.getText().toString().isEmpty()) {
            tvResultado.setText("Por favor, insira números válidos.");
            return;
        }

        double num1 = Double.parseDouble(etNum1.getText().toString());
        double num2 = Double.parseDouble(etNum2.getText().toString());
        double resultado = 0;

        switch (view.getId()) {
            case R.id.btnSomar:
                resultado = num1 + num2;
                break;
            case R.id.btnSubtrair:
                resultado = num1 - num2;
                break;
            case R.id.btnMultiplicar:
                resultado = num1 * num2;
                break;
            case R.id.btnDividir:
                // Verificação de divisão por zero
                if (num2 == 0) {
                    tvResultado.setText("Erro: Divisão por zero não é permitida.");
                    return;
                }
                resultado = num1 / num2;
                break;
        }

        tvResultado.setText("Resultado: " + resultado);
    }
}